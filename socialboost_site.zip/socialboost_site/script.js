function selectService(platform){
  document.getElementById("platform").value = platform;
  document.getElementById("service").value = "Продвижение " + platform;
  document.getElementById("order").scrollIntoView({behavior:"smooth"});
}
document.getElementById("orderForm").addEventListener("submit", function(e){
  e.preventDefault();
  const order = {
    platform: document.getElementById("platform").value,
    service: document.getElementById("service").value,
    link: document.getElementById("link").value,
    contact: document.getElementById("contact").value,
    created: new Date().toISOString()
  };
  localStorage.setItem("socialboost_last_order", JSON.stringify(order));
  document.getElementById("message").textContent =
    "Заявка принята в демо-режиме. Данные сохранены только в вашем браузере.";
  this.reset();
});
